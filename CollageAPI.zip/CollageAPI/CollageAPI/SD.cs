﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CollageAPI
{
    public class SD
    {
        public const string Role_Admin = "admin";
        public const string Role_Employee = "employee";
    }
}
